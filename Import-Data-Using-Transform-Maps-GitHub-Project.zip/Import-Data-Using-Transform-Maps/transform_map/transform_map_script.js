// Transform Map onBefore script
// Skip empty records
if (gs.nil(source.u_name)) {
    ignore = true;
}
