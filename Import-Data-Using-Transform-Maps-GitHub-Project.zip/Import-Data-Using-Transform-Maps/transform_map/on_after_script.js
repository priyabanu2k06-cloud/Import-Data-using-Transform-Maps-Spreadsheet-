// Transform Map onAfter script
gs.info('Record transformed successfully: ' + target.name);
