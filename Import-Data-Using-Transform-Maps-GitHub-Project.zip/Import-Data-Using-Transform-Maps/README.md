# Import Data Using Transform Maps (Spreadsheet)

ServiceNow project demonstrating how spreadsheet data can be imported into a target table using Import Sets and a Transform Map.

## Flow
Spreadsheet -> Import Set -> Transform Map -> Target Table

## Expected Result
Spreadsheet records are transformed and inserted into the target table.
